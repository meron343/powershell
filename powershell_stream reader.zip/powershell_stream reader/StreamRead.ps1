Write-Host "streamreadtest`n�t�H���_���̃t�@�C����ǂݎ���ď������܂��B"
Write-Host "�ϐ���ps1�t�@�C����ҏW���Ă��������B"

#$DebugPreference= "Continue"
$DebugPreference= "SilentlyContinue"
Write-Debug "debugMODE"

#$fpath = "C:\Users\++++\Documents\++\powershell_stream reader\in"
$fpath = $PSScriptRoot 
#+ "\in"
cd $fpath

$in_path=".\in"
Write-Host "���̓t�H���_�:$in_path"

$out_path =".\out"
Write-Host "�o�̓t�H���_�:$out_path"

$SKP_row = 35
Write-Host "�擪�ǂݔ�΂��s���:$SKP_row"

#$enc = [Text.Encoding]::GetEncoding("Shift_JIS")
$enc = [Text.Encoding]::GetEncoding("utf-8")
Write-Host "̧�ٴݺ��ިݸ�:$enc"

Write-Host "`n�����t�@�C���ꗗ"
$files = Get-ChildItem "$in_path\*.txt" -Recurse -file 
foreach($item in $files){
    Write-Host  "�t�@�C�����F$($item.Name)"
}

pause
$total_cyc_count= [long]0

foreach($item in $files){
    Write-output  "�������F$($item.Name)"

    #�s���v�Z�igetcontent����ƈٗl�ɒx����//https://qiita.com/Cobalt32/items/3bf2553f5a77345af190�j
    #StreamReader
    $fh = New-Object System.IO.StreamReader($item.fullname, $enc)
    $maxrow=[long]0
    while (($l = $fh.ReadLine()) -ne $null) {   $maxrow++    }
    Write-Host "�s���F$maxrow"
	

    #���߂ČJ��Ԃ�����
    $fh = New-Object System.IO.StreamReader($item.fullname, $enc)
    #���ٌ���
    $array = New-Object System.Collections.ArrayList
    $i=[long]0

    $L_flg=0		#L�t���O
    $H_flg=0		#H�t���O
    $L_count =0		#L�p����
    $H_count =0		#H�p����
    $cyc_count =[long]0	#

    for($k=0;$k -le $SKP_row ;$k++){
        $str = $fh.ReadLine()
    }#�s���w�萔�ǂݔ�΂�

    $start_time = Get-Date
    $d = Get-Date
    $d = $d.AddSeconds( 1 )
    while (($str = $fh.ReadLine()) -ne $null) {
            $i++
	    $Buffers = $str.split(',')
            [void]$array.Add($str)

	    $flg=1
	    $flg*=([double]$Buffers[3] -le 1.0)
	    $flg*=([double]$Buffers[4] -le 1.0)
	    $flg*=([double]$Buffers[5] -le 1.0)

	    if($flg){
               # write-host "L"
                $L_count++
            }else{
                if($L_count -ge 3){
                    $L_flg=1
                }
                $L_count =0
            }


	    $flg=1
	    $flg*=([double]$Buffers[3] -ge 9.5)
	    $flg*=([double]$Buffers[4] -ge 9.5)
	    $flg*=([double]$Buffers[5] -ge 9.5)

            if($flg){
               # write-host "H"
                 $H_count++ 
            }else{
                if($H_count -ge 3){
                    $H_flg=1
                    if ($L_flg){
                        $L_count =0
                        $H_count =0
                        $H_flg =0
                        $L_flg =0
                        $cyc_count++
			$total_cyc_count++
                        Write-Debug  "cycle: $cyc_count / $total_cyc_count "
                        $save_name= $out_path +"\"+ $total_cyc_count.tostring("0000CYC") + $item.Name
                        #write-host "save_name= $save_name"
                        Set-Content -Path $save_name -value $array -Encoding UTF8
                        Remove-Variable array
                        $array = New-Object System.Collections.ArrayList

                    }
                }
                $H_count =0
            }

	    <# 1S���ƕ\�� #>
	    $now = Get-Date
	    if($now -lt $d){

	    }else{
		 $persent= ([double]$i/[double]$maxrow *100.0 ).tostring("000.0")
		 $difference = ($d - $start_time).seconds
		 $wait_time=((100.0 - $persent)/($difference / $persent)).tostring("000.0")

		 [System.Console]::Write("`r �s���F$i / $persent % �\�z����$wait_time [s] `r")
	         $d = $d.AddSeconds( 1 )
		$persent_tmp=$persent
	    }
	    <# 1S���ƕ\�� #>

    }
    [System.Console]::Write("`r �s���F$i / 100.0 %  `r")

    $fh.close
        
}
