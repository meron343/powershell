﻿$SKIP=$true;iex ((gc $MyInvocation.InvocationName|%{
    if ($SKIP -and ($_ -notmatch "^####FuncDef\s*$")){return}
    $SKIP=$false
    $_
})-join "`r`n")

Write-Host "POWER_VISA 3k2 by#343"
Write-Host "R7．1.23 "


. ".\SUBFUNC\00_SUB_POWER_COM_1k1"
. ".\SUBFUNC\01_SUB_FUNC"
. ".\SUBFUNC\UIA_FUNC2k2"

DEV_OPN "DX SKT 192.168.1.1:34260"
QUE_CMD "DX,S,admin"
QUE_CMD "DX,Q,0"

UIA_INIT "電卓,1000,0"
UIA_CHK "1"

UIA_WINDOW_L_CLK_S "211,476" #0
UIA_WINDOW_L_CLK_S "78,421" #1
UIA_WINDOW_L_CLK_S "212,422" #2
UIA_WINDOW_L_CLK_S "342,421,20,1" #3
UIA_WINDOW_L_CLK_S "78,373,20,1" #4
UIA_WINDOW_L_CLK_S "210,371,20,1" #5
UIA_WINDOW_L_CLK_S "344,370,20,1" #6
UIA_WINDOW_L_CLK_S "76,327,20,1" #7
UIA_WINDOW_L_CLK_S "210,324,20,1" #8
UIA_WINDOW_L_CLK_S "350,320,20,1" #9



while($true) {
	#MSG_dev

	SUB_KEYINPUT_EXEC #キー入力時に関数実行（デバック用）
	Start-Sleep -Milliseconds 50

	UIA_MOUSE_CHK
}





####FuncDef   


function SUB_KEYINPUT_EXEC{
	if([Console]::KeyAvailable){
		$message = Read-Host "Input a message "
		$BUF= $message.split(' ',2)

		try{
			if($BUF.length -lt 2){
				$ReturnValude = & $BUF[0]
				Write-Host  RTN: "$ReturnValude"
			}else{


			Write-Host $BUF[0] $BUF[1]
	                $FUNC   = $BUF[0]
			$HIKISU = $BUF[1].replace("""","")
				$ReturnValude = & $FUNC $HIKISU
				Write-Host  RTN: "$ReturnValude"
			}

		}catch{
			Write-Host コマンドが違います
			$FUNC_List = Get-ChildItem Function:
			#$#FUNC=$FUNC_List.split(':')
			Write-Host $FUNC
		}
	}
}


function SUB_END{
	#終了時実行コマンド実行位置
}
