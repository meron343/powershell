﻿<#
#操作対象ウィンドウの検索
UIA_SERCH *

#操作対象セット（完全一致必須）
UIA_INIT 電卓


UIA_KEY_STR "MOJI_RETSU_INPUT"

#キー入力
UIA_KEY_PS "^a"
UIA_KEY_PS "^c"
UIA_KEY_PS "%{F4}"
$Gettext = Get-Clipboard 
Write-Host $Gettext

`a
#UIA表示機能
UIA_CHK 0 #:UIA_CHK_MOUSE Disable
UIA_CHK 1 #:UIA_CHK_MOUSE Enable
UIA_CHK 2 #UIA_CHK_MOUSEsoutai_Enable


#相対位置クリック
UIA_WINDOW_L_CLK_S

#相対位置マウス移動
UIA_WINDOW_CURS_MV 1,1

#絶対位置マウス移動
UIA_WINDOW_CURS_MV 1,1,0,0

#絶対座標クリック
UIA_L_CLK_S
#>

Add-Type @"
using System;
using System.Runtime.InteropServices;

public struct RECT{
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
}


public class User32 {
    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    
    [DllImport("user32.dll")]
    public static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder lpString, int nMaxCount);
    
    [DllImport("user32.dll")]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    public const int SW_SHOWNORMAL = 1;
}

public class WinAPI
{
        // ウインドウの現在の座標データを取得する関数
        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        // ウインドウの座標を変更する関数
        [DllImport("user32.dll")]
        public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
}


"@


#UIA_INIT "電卓"
$global:UIA_X=0
$global:UIA_Y=0

function UIA_INIT($str){
	$buff= $str.split(",")

        $global:windowNames=    [string]"電卓"
	$global:x		=[int]0
	$global:y		=[int]0
	$width		=[int]500
	$hight		=[int]500
       if($buff.length -ge 1){	$global:windowNames = [string]$buff[0]  }
       if($buff.length -ge 2){	$global:UIA_X	    = [int]$buff[1]	}
       if($buff.length -ge 3){	$global:UIA_Y	    = [int]$buff[2]	}
       if($buff.length -ge 4){	$width		    = [int]$buff[3]	}
       if($buff.length -ge 5){	$hight		    = [int]$buff[4]	}
       Write-Host $buff

	#ADDTYPE

	$windowNameArray = $windowNames -split '\s+'
	$global:windw_cnt=0
	$enumCallback = {
    		param ($hWnd, $lParam)

	$sb = New-Object System.Text.StringBuilder 256
    	$wndText = [User32]::GetWindowText($hWnd, $sb, $sb.Capacity)

    	if ($wndText -gt 0) {
        	$windowTitle = $sb.ToString()

        	foreach ($windowName in $windowNameArray) {



	#		完全一致に変更
	             if ($windowTitle -eq "$windowName") {
	#             if ($windowTitle -like "$windowName") {
			$rc = New-Object RECT
			[WinAPI]::GetWindowRect($hWnd, [ref]$rc)
			$global:UIAwindowName =$windowTitle
			$global:windw_cnt++
			$global:UIA_X= $rc.Left
			$global:UIA_Y= $rc.Top
			$global:UIA_W= $rc.Right - $rc.Left
	        	$global:UIA_H=  $rc.Bottom -$rc.Top
	                Write-Host "Name: $windw_cnt $windowTitle ($global:UIA_X, $global:UIA_Y)($global:UIA_W, $global:UIA_H)"


	                [User32]::ShowWindow($hWnd, [User32]::SW_SHOWNORMAL) | Out-Null
	                [User32]::SetForegroundWindow($hWnd) | Out-Null
	                #[User32]::SetWindowPos($hWnd, [IntPtr]::Zero, $x, $y, $width, $hight, 0) | Out-Null
	                break
	            }
	        }
	    }
		return $true
	}






	[User32]::EnumWindows($enumCallback, [IntPtr]::Zero) | Out-Null


	# .NET Frameworkの宣言
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

	# Windows APIの宣言
	$signature=@'
	[DllImport("user32.dll",CharSet=CharSet.Auto,CallingConvention=CallingConvention.StdCall)]
	public static extern void mouse_event(long dwFlags, long dx, long dy, long cButtons, long dwExtraInfo);
'@
	$global:SendMouseClick = Add-Type -memberDefinition $signature -name "Win32MouseEventNew" -namespace Win32Functions -passThru

	#Start-Sleep -s 1

}


# UIA_SERCH "Program Manager"
function UIA_SERCH($str){
	$buff= $str.split(",")

        $global:windowNames=    [string]"電卓"
	$global:x		=[int]0
	$global:y		=[int]0
	$width		=[int]500
	$hight		=[int]500
       if($buff.length -ge 1){	$global:windowNames = [string]$buff[0]	}
       if($buff.length -ge 2){	$global:UIA_X	    = [int]$buff[1]	}
       if($buff.length -ge 3){	$global:UIA_Y	    = [int]$buff[2]	}
       if($buff.length -ge 4){	$width		    = [int]$buff[3]	}
       if($buff.length -ge 5){	$hight		    = [int]$buff[4]	}
       Write-Host $buff

	#ADDTYPE

	$windowNameArray = $windowNames -split '\s+'

	$enumCallback = {
    		param ($hWnd, $lParam)

	$sb = New-Object System.Text.StringBuilder 256
    	$wndText = [User32]::GetWindowText($hWnd, $sb, $sb.Capacity)

    	if ($wndText -gt 0) {
        	$windowTitle = $sb.ToString()

        	foreach ($windowName in $windowNameArray) {



	#		完全一致に変更
	#             if ($windowTitle -eq "$windowName") {
	              if ($windowTitle -like "$windowName") {
			$rc = New-Object RECT
			[WinAPI]::GetWindowRect($hWnd, [ref]$rc)

			$global:UIA_X= $rc.Left
			$global:UIA_Y= $rc.Top
			$global:UIA_W= $rc.Right - $rc.Left
			$global:UIA_H=  $rc.Bottom -$rc.Top
	                Write-Host "Name: $windowTitle ($global:UIA_X, $global:UIA_Y)($global:UIA_W, $global:UIA_H)"


	                #[User32]::ShowWindow($hWnd, [User32]::SW_SHOWNORMAL) | Out-Null
	                #[User32]::SetForegroundWindow($hWnd) | Out-Null
	                #[User32]::SetWindowPos($hWnd, [IntPtr]::Zero, $x, $y, $width, $hight, 0) | Out-Null
	                break
	            }
	        }
	    }
	    return $true
	}
	[User32]::EnumWindows($enumCallback, [IntPtr]::Zero) | Out-Null


	# .NET Frameworkの宣言
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
	[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 






}





#文字入力用
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms

function UIA_KEY_PS($STR){
    	[System.Windows.Forms.SendKeys]::SendWait(   $STR   )
	Start-Sleep -Milliseconds 100
	Write-Host UIA_Press_key:$STR
}

function UIA_KEY_STR($STR){
    $str_array = $STR.ToCharArray()

    #配列を取り出す
    foreach ($msg in $str_array) {
    	[System.Windows.Forms.SendKeys]::SendWait(   $msg   )
	Start-Sleep -Milliseconds 100

    }
    Write-Host UIA_tx_send:$STR

}











#マウスを指定位置に移動
#UIA_L_CLK_DD "524,126,0,0 > -129,0"
function UIA_WINDOW_CURS_MV ($str){
	$buff= $str.split(",")
	Write-Host  "mv:index $($buff.count.ToString("000"))/str:$str"
       if($buff.count -ge 1){	$soutai_x =[int]$buff[0]	
                                Write-Host 1	}
       if($buff.count -ge 2){	$soutai_y =[int]$buff[1]	}
       if($buff.count -ge 3){	$kizyun_x =[int]$buff[2]	}
	else{$kizyun_x= $global:UIA_X}
       if($buff.count -ge 4){	$kizyun_y =[int]$buff[3] }
	else{$kizyun_y= $global:UIA_Y}

	Write-Host  $soutai_x ,$soutai_y , $kizyun_x , $kizyun_y
 	if($buff.count -ge 4){
	$soutai_x += $kizyun_x
	$soutai_y += $kizyun_y
	}
	Write-Host -NoNewline $soutai_x ,$soutai_y

	[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point([int]$soutai_x, [int]$soutai_y)
	Write-Host UIA_CURSR_MV X:$soutai_x Y:$soutai_y
}
function UIA_CURS_MV ($str){
	$buff= $str.split(",")
	Write-Host  "mv:index $($buff.count.ToString("000"))/str:$str"
       if($buff.count -ge 1){	$soutai_x =[int]$buff[0]	}
       if($buff.count -ge 2){	$soutai_y =[int]$buff[1]	}
       if($buff.count -ge 3){	$kizyun_x =[int]$buff[2]	}
       if($buff.count -ge 4){	$kizyun_y =[int]$buff[3] }

	Write-Host  $soutai_x ,$soutai_y , $kizyun_x , $kizyun_y
 	if($buff.count -ge 4){
		$soutai_x += $kizyun_x
		$soutai_y += $kizyun_y
	}
	Write-Host -NoNewline $soutai_x ,$soutai_y

	[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point([int]$soutai_x, [int]$soutai_y)
	Write-Host UIA_CURSR_MV X:$soutai_x Y:$soutai_y
}

#マウスクリック



function UIA_L_CLK_ON {	$SendMouseClick::mouse_event(0x0002, 0, 0, 0, 0);} #Lクリック押し
function UIA_L_CLK_OF {	$SendMouseClick::mouse_event(0x0004, 0, 0, 0, 0);} #Lクリック離し
function UIA_R_CLK_ON {	$SendMouseClick::mouse_event(0x0008, 0, 0, 0, 0);} #Rクリック押し
function UIA_R_CLK_OF {	$SendMouseClick::mouse_event(0x0010, 0, 0, 0, 0);} #Rクリック離し

#UIA_WINDOW_L_CLK_S "78,421" #1
function UIA_WINDOW_L_CLK_S($str){
	UIA_INIT  $global:UIAwindowName
	if($global:windw_cnt -eq 1){

		Write-Host "CLK_L"
	        $str+= ","
	        $str+= $global:UIA_X.ToString("000")
	        $str+= ","
	        $str+= $global:UIA_Y.ToString("000")
		UIA_WINDOW_CURS_MV ($str)
		UIA_L_CLK_ON
		Start-Sleep -Milliseconds 100
		UIA_L_CLK_OF
	}else{
		Write-Host "Windw_handle_err"
	}

}


function UIA_L_CLK_S($str){
	UIA_CURS_MV $str
	UIA_L_CLK_ON
	Start-Sleep -Milliseconds 100
	UIA_L_CLK_OF
}

#
#UIA_L_CLK_DD "524,126,0,0 > -129,0"
function UIA_L_CLK_DD($str2){
	$str= $str2.split(">")
	#Write-Host STR0:$($str[0])
	#Write-Host STR1:$($str[1])

	$buff_STR= $str[0].split(",")
	$buff_END= $str[1].split(",")
	Write-Host "STR: $($buff_STR[0])/$($buff_STR[1])/$($buff_STR[2])/$($buff_STR[3])"
	Write-Host "END: $($buff_END[0])/$($buff_END[1])"


       if($buff_STR.count -ge 1){	$soutai_x =[long]$buff_STR[0]	}
       if($buff_STR.count -ge 2){	$soutai_y =[long]$buff_STR[1]	}
       if($buff_STR.count -ge 3){	$kizyun_x =[long]$buff_STR[2]	}
       if($buff_STR.count -ge 4){	$kizyun_y =[long]$buff_STR[3]	}

       if($buff_END.count -ge 1){	$soutai_dst_x =[long]$buff_END[0]	}
       if($buff_END.count -ge 2){	$soutai_dst_y =[long]$buff_END[1]
					Write-Host 5	}

	Write-Host STS: $($soutai_x) , $($soutai_y) , $($kizyun_x) , $($kizyun_y)
	Write-Host END: $($soutai_dst_x) ,$($soutai_dst_y)

	$soutai_x += $kizyun_x
	$soutai_y += $kizyun_y
	Write-Host "DDEND: $($soutai_x) ,$($soutai_y)"


	[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point([int]$soutai_x, [int]$soutai_y)
	#Write-Host UIA_CURSR_MV X:$soutai_x Y:$soutai_y
	$SendMouseClick::mouse_event(0x0002, 0, 0, 0, 0);
	#Start-Sleep -Milliseconds 10

	$soutai_x = $soutai_x + [long]$soutai_dst_x
	$soutai_y = $soutai_y + [long]$soutai_dst_y
	#Write-Host "DDEND: $($soutai_x) ,$($soutai_y)"

	[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point([int]$soutai_x, [int]$soutai_y)
	#Write-Host UIA_CURSR_MV X:$soutai_x Y:$soutai_y

	Start-Sleep -Milliseconds 10
	$SendMouseClick::mouse_event(0x0004, 0, 0, 0, 0);




}








function UIA_MOUSE_SAVE{
	$global:Mouse_def_pos_X = [System.Windows.Forms.Cursor]::Position.X
	$global:Mouse_def_pos_Y = [System.Windows.Forms.Cursor]::Position.Y
} #マウス位置の保存
function UIA_MOUSE_RTN{
	[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($Mouse_def_pos_X, $Mouse_def_pos_Y)
} #マウス位置の復帰

##マウス検知用

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 
	#左クリック時の戻り値を計算
	$L_CLK = [System.Windows.Forms.MouseButtons]::Left.value__
	$R_CLK = [System.Windows.Forms.MouseButtons]::Right.value__
	$MouseValuetemp= [System.Windows.Forms.Control]::MouseButtons.value__
#$text= [System.Windows.Forms.Control]::ModifierKeys.Tostring("")

##マウス検知用
$global:UIA_CHK_FLG=0
#UIA_CHK "1"
function UIA_CHK( $UIA_CHK_F ){
$SW=$UIA_CHK_F

	Write-Host "0:UIA_CHK_MOUSE Disable"
	Write-Host "1:UIA_CHK_MOUSE Enable"
	Write-Host "1:UIA_CHK_MOUSEsoutai_Enable "
#	Write-Host "3:input_coment"
#	Write-Host "4:save_all_log"


	#$sw = Read-Host "SET COM="
	switch( $SW ){
		    "0" {
			$global:UIA_CHK_FLG =[int]0
		    }
		    "1" {
			$global:UIA_CHK_FLG =[int]1
			Write-Host "UIA_CHK_MOUSE Enable"
		    }
		    "2" {
			$global:UIA_CHK_FLG =[int]2
			Write-Host "UIA_CHK_MOUSE_soutai Enable"
		    }


		    Default {}
		}




}


function UIA_MOUSE_CHK(){
$sw = $global:UIA_CHK_FLG


#UIA_CHK "_"
if(0 -eq $sw){
}else{


	#クリック時の戻り値を計算
	$MouseValue= [System.Windows.Forms.Control]::MouseButtons.value__

	if($MouseValue  -eq $global:MouseValuetemp){

	}else{
		switch ($MouseValue) {
		    $L_CLK {

			$MouseEV= "UIA_L_CLK_S"
		    }
		    $R_CLK {

			$MouseEV= "UIA_R_CLK_S"
		    }

		    Default {
		        $MouseEV= $MouseValue.ToString()
		    }
		}

		$X = [System.Windows.Forms.Cursor]::Position.X
		$Y = [System.Windows.Forms.Cursor]::Position.Y

		


		 if($MouseValue -eq 0){#マウスボタン離す
			if( ($X -ne $global:tempX)-or ($Y -ne $global:tempY)){
				#Write-Host "UIA_L_CLK_DDex: `"385,130,0,0 > 527,124`""

				if(1 -eq $sw){
					Write-Host "UIA_L_CLK_DD `"$($global:tempX),$($global:tempY),$(0),$(0)>$($X - $global:tempX),$($Y - $global:tempY)`""
				}else{
					Write-Host "UIA_L_CLK_DD `"$($global:tempX - $global:UIA_X),$($global:tempY-$global:UIA_Y),$global:UIA_X,$global:UIA_Y >$($X - $global:tempX),$($Y - $global:tempY)`""
				}
			}else{
				
				#Write-Host "CLK_TYPE,relative:x,y,RefPOS:x,RefPOS:y"
				if(1 -eq $sw){
					Write-Host "$($global:MouseEV2) `"$($X),$($Y),$(0),$(0)`""
				}else{
					Write-Host "UIA_WINDOW_L_CLK_S `"$($X - $global:UIA_X),$($Y-$global:UIA_Y),$global:UIA_X,$global:UIA_Y"					
				}


			}
		}else{
			#文字を置くちゃう
	 		#[System.Windows.Forms.SendKeys]::SendWait("{`a}") #sendkey
			#マウス動かしちゃう
			#[System.Windows.Forms.Cursor]::Position= New-Object System.Drawing.Point(1, 1)
			$global:MouseEV2 = $MouseEV

	
		}
		$global:tempX =$X
		$global:tempY =$Y


	}

	#Start-Sleep -Milliseconds 100
	
	$global:MouseValuetemp=$MouseValue

}

#Read-Host
}