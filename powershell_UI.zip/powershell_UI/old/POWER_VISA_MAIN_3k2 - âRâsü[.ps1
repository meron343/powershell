﻿$SKIP=$true;iex ((gc $MyInvocation.InvocationName|%{
    if ($SKIP -and ($_ -notmatch "^####FuncDef\s*$")){return}
    $SKIP=$false
    $_
})-join "`r`n")

Write-Host "POWER_VISA 3k2 by#343"
Write-Host "R7．1.23 "


. ".\SUBFUNC\00_SUB_POWER_COM_1k1"
. ".\SUBFUNC\01_SUB_FUNC"
<#DEV_OPN "FK200 COM COM25:9600"

QUE_CMD "FK200,S,ADDR 1"
QUE_CMD "FK200,S,SYST:COMM:SER:PACE OFF"
QUE_CMD "FK200,QC,SYST:COMM:SER:PACE?"
QUE_CMD "FK200,Q,*IDN?"

QUE_CMD "FK200,S,CURR 1.0"
QUE_CMD "FK200,S,LOAD ON"

#>
while($true) {

	SUB_KEYINPUT_EXEC #キー入力時に関数実行（デバック用）
	Start-Sleep -Milliseconds 50
}

####FuncDef   
function SUB_KEYINPUT_EXEC{
	if([Console]::KeyAvailable){
		$message = Read-Host "Input a message "
		$BUF= $message.split(' ',2)

		try{
			if($BUF.length -lt 2){
				$ReturnValude = & $BUF[0]
				Write-Host  RTN: "$ReturnValude"
			}else{


			Write-Host $BUF[0] $BUF[1]
	                $FUNC   = $BUF[0]
			$HIKISU = $BUF[1].replace("""","")
				$ReturnValude = & $FUNC $HIKISU
				Write-Host  RTN: "$ReturnValude"
			}

		}catch{
			Write-Host コマンドが違います
			$FUNC_List = Get-ChildItem Function:
			#$#FUNC=$FUNC_List.split(':')
			Write-Host $FUNC
		}
	}
}

function SUB_END{
	#終了時実行コマンド実行位置
}
